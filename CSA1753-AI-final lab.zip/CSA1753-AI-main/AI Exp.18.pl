% Database of Name and Date of Birth

person(afnan, date(12, 5, 2003)).
person(ali,   date(25, 8, 2001)).
person(sara,  date(3,  1, 2004)).
