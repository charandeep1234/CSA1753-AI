% student(StudentName, SubjectCode).
student(afnan, cs101).
student(ali,   cs102).
student(sara,  cs101).

% teacher(TeacherName, SubjectCode).
teacher(ramesh, cs101).
teacher(priya,  cs102).

% subject(SubjectCode, SubjectName).
subject(cs101, programming).
subject(cs102, data_structures).
